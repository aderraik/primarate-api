package com.visiansystems.dao.generator;

public interface ITableGenerator {
    public void createTable();
}
