package com.visiansystems.bl.bankRateFeed.ecb;

public class EcbRpcParserTest {
}
