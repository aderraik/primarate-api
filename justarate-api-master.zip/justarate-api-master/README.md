### Just a Rate

#### Requirements

* Java 8
* Gradle

#### Building and running local server

`> gradle build appRun`

#### Usage

http://localhost:8081/justarate/convert/{centralBankId}/{currencyIn}/{amount}/{currencyOut}

Example:
[http://localhost:8081/justarate/convert/1/EUR/10/USD](http://localhost:8081/justarate/convert/1/EUR/10/USD)

#### Central Banks

1 Brazil's Central Bank
2 European Central Bank

