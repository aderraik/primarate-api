package com.visiansystems;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource({"classpath*:main-context.xml"})
public class BankRatesConfig {

}
